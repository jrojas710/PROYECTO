package com.ghl_unab.dao;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.SQLException;
import java.sql.Statement;

public class Database {

    private static final String URL = "jdbc:sqlite:ghl_unab.db";
    private static Connection connection;

    public static Connection getConnection() throws SQLException {
        if (connection == null || connection.isClosed()) {
            try {
                Class.forName("org.sqlite.JDBC");
            } catch (ClassNotFoundException e) {
                System.err.println("Driver SQLite no encontrado. Agrega sqlite-jdbc al proyecto.");
            }
            connection = DriverManager.getConnection(URL);
        }
        return connection;
    }

    public static void init() {
        try (Connection conn = getConnection(); Statement st = conn.createStatement()) {
            st.executeUpdate("CREATE TABLE IF NOT EXISTS usuarios (" +
                    "id INTEGER PRIMARY KEY AUTOINCREMENT," +
                    "nombre TEXT NOT NULL," +
                    "correo TEXT NOT NULL UNIQUE," +
                    "programa TEXT," +
                    "password_hash TEXT NOT NULL," +
                    "rol TEXT NOT NULL)");
            st.executeUpdate("CREATE TABLE IF NOT EXISTS eventos (" +
                    "id INTEGER PRIMARY KEY AUTOINCREMENT," +
                    "nombre TEXT NOT NULL," +
                    "tipo TEXT NOT NULL," +
                    "fecha TEXT NOT NULL," +
                    "horas INTEGER NOT NULL," +
                    "lugar TEXT)");
            st.executeUpdate("CREATE TABLE IF NOT EXISTS registros_hl (" +
                    "id INTEGER PRIMARY KEY AUTOINCREMENT," +
                    "estudiante_id INTEGER NOT NULL," +
                    "evento_id INTEGER NOT NULL," +
                    "fecha TEXT NOT NULL," +
                    "horas INTEGER NOT NULL," +
                    "estado TEXT NOT NULL," +
                    "FOREIGN KEY(estudiante_id) REFERENCES usuarios(id)," +
                    "FOREIGN KEY(evento_id) REFERENCES eventos(id))");
        } catch (SQLException e) {
            e.printStackTrace();
        }
    }
}
