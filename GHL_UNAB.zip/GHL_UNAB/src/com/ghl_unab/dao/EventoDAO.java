package com.ghl_unab.dao;

import com.ghl_unab.model.Evento;

import java.sql.*;
import java.time.LocalDate;
import java.util.ArrayList;
import java.util.List;

public class EventoDAO {

    public void insertar(Evento e) throws SQLException {
        String sql = "INSERT INTO eventos (nombre, tipo, fecha, horas, lugar) VALUES (?,?,?,?,?)";
        try (Connection conn = Database.getConnection();
             PreparedStatement ps = conn.prepareStatement(sql)) {
            ps.setString(1, e.getNombre());
            ps.setString(2, e.getTipo());
            ps.setString(3, e.getFecha().toString());
            ps.setInt(4, e.getHoras());
            ps.setString(5, e.getLugar());
            ps.executeUpdate();
        }
    }

    public List<Evento> findAll() throws SQLException {
        List<Evento> lista = new ArrayList<>();
        String sql = "SELECT * FROM eventos";
        try (Connection conn = Database.getConnection();
             Statement st = conn.createStatement();
             ResultSet rs = st.executeQuery(sql)) {

            while (rs.next()) {
                int id = rs.getInt("id");
                String nombre = rs.getString("nombre");
                String tipo = rs.getString("tipo");
                LocalDate fecha = LocalDate.parse(rs.getString("fecha"));
                int horas = rs.getInt("horas");
                String lugar = rs.getString("lugar");

                lista.add(new Evento(id, nombre, tipo, fecha, horas, lugar));
            }
        }
        return lista;
    }

    // ==============================
    //   SEED AUTOMÁTICO DE EVENTOS
    // ==============================
    public void seed() throws SQLException {

        // Si ya hay eventos, no hace nada
        if (!findAll().isEmpty()) return;

        // 1–7 (los básicos que mencionaste)
        insertar(new Evento("ULIBRO", "CULTURAL",
                LocalDate.of(2025, 9, 15), 3, "Biblioteca UNAB"));

        insertar(new Evento("UNABFEST", "ARTISTICO",
                LocalDate.of(2025, 9, 30), 4, "Campus Principal"));

        insertar(new Evento("Hackatón Innovación", "TECNOLOGICO",
                LocalDate.of(2025, 10, 20), 5, "Laboratorio de Innovación"));

        insertar(new Evento("Semana de la Ingeniería", "ACADEMICO",
                LocalDate.of(2025, 5, 12), 4, "Auditorio Mayor"));

        insertar(new Evento("Club de Ajedrez", "RECREATIVO",
                LocalDate.of(2025, 6, 5), 2, "Bloque C - Aula 104"));

        insertar(new Evento("Atletismo UNAB", "DEPORTIVO",
                LocalDate.of(2025, 8, 21), 3, "Cancha Atlética"));

        insertar(new Evento("Semana del Arte", "CULTURAL",
                LocalDate.of(2025, 4, 10), 3, "Sala de Exposiciones"));

        // 8–20+ adicionales

        insertar(new Evento("Cine Foro Ambiental", "CULTURAL",
                LocalDate.of(2025, 3, 18), 2, "Auditorio Menor"));

        insertar(new Evento("Voluntariado Ambiental", "SOCIAL",
                LocalDate.of(2025, 4, 25), 4, "Parque Las Palmas"));

        insertar(new Evento("Feria de Emprendimiento", "EMPRESARIAL",
                LocalDate.of(2025, 11, 8), 4, "Plazoleta Central"));

        insertar(new Evento("TEDx UNAB", "ACADEMICO",
                LocalDate.of(2025, 7, 3), 3, "Auditorio Mayor"));

        insertar(new Evento("Torneo E-Sports", "RECREATIVO",
                LocalDate.of(2025, 6, 28), 3, "Laboratorio Multimedia"));

        insertar(new Evento("Campeonato de Fútbol", "DEPORTIVO",
                LocalDate.of(2025, 5, 30), 4, "Cancha Sintética"));

        insertar(new Evento("Jornada de Donación de Sangre", "SOCIAL",
                LocalDate.of(2025, 9, 5), 2, "Bloque B - Hall"));

        insertar(new Evento("Seminario de Seguridad Digital", "ACADEMICO",
                LocalDate.of(2025, 3, 12), 2, "Sala de Conferencias"));

        insertar(new Evento("Festival de Música UNAB", "ARTISTICO",
                LocalDate.of(2025, 10, 4), 4, "Plazoleta Central"));

        insertar(new Evento("Taller de Liderazgo", "ACADEMICO",
                LocalDate.of(2025, 2, 20), 2, "Bloque D - Aula 301"));

        insertar(new Evento("Club de Lectura", "CULTURAL",
                LocalDate.of(2025, 1, 22), 2, "Biblioteca - Sala 2"));

        insertar(new Evento("Jornada de Ciencia de Datos", "ACADEMICO",
                LocalDate.of(2025, 11, 15), 3, "Bloque E - Auditorio"));

        insertar(new Evento("Congreso de Innovación", "ACADEMICO",
                LocalDate.of(2025, 8, 10), 5, "Centro de Convenciones"));

        insertar(new Evento("Taller de Fotografía Digital", "ARTISTICO",
                LocalDate.of(2025, 4, 3), 2, "Laboratorio de Fotografía"));

        insertar(new Evento("Rally de Programación", "TECNOLOGICO",
                LocalDate.of(2025, 5, 18), 4, "Bloque F - Sala de Cómputo"));

        insertar(new Evento("Día del Libro", "CULTURAL",
                LocalDate.of(2025, 4, 23), 2, "Biblioteca - Terraza"));

        insertar(new Evento("Voluntariado Adulto Mayor", "SOCIAL",
                LocalDate.of(2025, 6, 14), 3, "Hogar Geriátrico San José"));

        insertar(new Evento("Foro de Derechos Humanos", "ACADEMICO",
                LocalDate.of(2025, 12, 2), 3, "Sala de Juntas"));

        insertar(new Evento("Torneo de Tenis de Mesa", "DEPORTIVO",
                LocalDate.of(2025, 3, 27), 2, "Gimnasio UNAB"));

        insertar(new Evento("Semana de la Salud Mental", "SOCIAL",
                LocalDate.of(2025, 10, 18), 3, "Centro de Bienestar"));
    }
}
