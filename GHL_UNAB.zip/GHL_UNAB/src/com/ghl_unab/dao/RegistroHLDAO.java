package com.ghl_unab.dao;

import com.ghl_unab.model.RegistroHL;

import java.sql.*;
import java.time.LocalDate;
import java.util.ArrayList;
import java.util.List;

public class RegistroHLDAO {

    public void insertar(RegistroHL r) throws SQLException {
        String sql = "INSERT INTO registros_hl " +
                "(estudiante_id, evento_id, fecha, horas, estado) " +
                "VALUES (?,?,?,?,?)";
        try (Connection conn = Database.getConnection();
             PreparedStatement ps = conn.prepareStatement(sql)) {
            ps.setInt(1, r.getEstudianteId());
            ps.setInt(2, r.getEventoId());
            ps.setString(3, r.getFecha().toString());
            ps.setInt(4, r.getHoras());
            ps.setString(5, r.getEstado());
            ps.executeUpdate();
        }
    }

    public List<RegistroHL> findByEstudiante(int estudianteId) throws SQLException {
        List<RegistroHL> lista = new ArrayList<>();
        String sql = "SELECT * FROM registros_hl WHERE estudiante_id = ?";
        try (Connection conn = Database.getConnection();
             PreparedStatement ps = conn.prepareStatement(sql)) {
            ps.setInt(1, estudianteId);
            ResultSet rs = ps.executeQuery();
            while (rs.next()) {
                int id = rs.getInt("id");
                int eventoId = rs.getInt("evento_id");
                LocalDate fecha = LocalDate.parse(rs.getString("fecha"));
                int horas = rs.getInt("horas");
                String estado = rs.getString("estado");
                lista.add(new RegistroHL(id, estudianteId, eventoId, fecha, horas, estado));
            }
        }
        return lista;
    }

    public int sumHorasValidadas(int estudianteId) throws SQLException {
        String sql = "SELECT SUM(horas) FROM registros_hl " +
                     "WHERE estudiante_id = ? AND estado = 'VALIDADA'";
        try (Connection conn = Database.getConnection();
             PreparedStatement ps = conn.prepareStatement(sql)) {
            ps.setInt(1, estudianteId);
            ResultSet rs = ps.executeQuery();
            if (rs.next()) return rs.getInt(1);
        }
        return 0;
    }

    // NUEVO: actualizar horas y estado de un registro
    public void actualizarHorasYEstado(int id, int horas, String estado) throws SQLException {
        String sql = "UPDATE registros_hl SET horas = ?, estado = ? WHERE id = ?";
        try (Connection conn = Database.getConnection();
             PreparedStatement ps = conn.prepareStatement(sql)) {
            ps.setInt(1, horas);
            ps.setString(2, estado);
            ps.setInt(3, id);
            ps.executeUpdate();
        }
    }

    // NUEVO: eliminar un registro por id
    public void eliminar(int id) throws SQLException {
        String sql = "DELETE FROM registros_hl WHERE id = ?";
        try (Connection conn = Database.getConnection();
             PreparedStatement ps = conn.prepareStatement(sql)) {
            ps.setInt(1, id);
            ps.executeUpdate();
        }
    }
}
