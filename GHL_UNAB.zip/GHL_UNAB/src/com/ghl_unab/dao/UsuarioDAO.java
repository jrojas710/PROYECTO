package com.ghl_unab.dao;

import com.ghl_unab.model.Usuario;

import java.sql.*;

public class UsuarioDAO {

    public Usuario login(String correo, String passHash) throws SQLException {
        String sql = "SELECT * FROM usuarios WHERE correo=? AND password=?";
        try (Connection conn = Database.getConnection();
             PreparedStatement ps = conn.prepareStatement(sql)) {

            ps.setString(1, correo);
            ps.setString(2, passHash);

            ResultSet rs = ps.executeQuery();
            if (rs.next()) {
                return new Usuario(
                        rs.getInt("id"),
                        rs.getString("nombre"),
                        rs.getString("correo"),
                        rs.getString("password"),
                        rs.getString("programa"),
                        rs.getString("rol")
                );
            }
        }
        return null;
    }

    public void insertar(Usuario u) throws SQLException {
        String sql = "INSERT INTO usuarios (nombre, correo, password, programa, rol) VALUES (?,?,?,?,?)";

        try (Connection conn = Database.getConnection();
             PreparedStatement ps = conn.prepareStatement(sql)) {

            ps.setString(1, u.getNombre());
            ps.setString(2, u.getCorreo());
            ps.setString(3, u.getPassword());
            ps.setString(4, u.getPrograma());
            ps.setString(5, u.getRol());

            ps.executeUpdate();
        }
    }
}
