package com.ghl_unab.model;

import java.time.LocalDate;

public class Evento implements Comparable<Evento> {
    private int id;
    private String nombre;
    private String tipo;
    private LocalDate fecha;
    private int horas;
    private String lugar;

    public Evento(int id, String nombre, String tipo, LocalDate fecha, int horas, String lugar) {
        this.id = id;
        this.nombre = nombre;
        this.tipo = tipo;
        this.fecha = fecha;
        this.horas = horas;
        this.lugar = lugar;
    }

    public Evento(String nombre, String tipo, LocalDate fecha, int horas, String lugar) {
        this(0, nombre, tipo, fecha, horas, lugar);
    }

    public int getId() { return id; }
    public void setId(int id) { this.id = id; }
    public String getNombre() { return nombre; }
    public void setNombre(String nombre) { this.nombre = nombre; }
    public String getTipo() { return tipo; }
    public void setTipo(String tipo) { this.tipo = tipo; }
    public LocalDate getFecha() { return fecha; }
    public void setFecha(LocalDate fecha) { this.fecha = fecha; }
    public int getHoras() { return horas; }
    public void setHoras(int horas) { this.horas = horas; }
    public String getLugar() { return lugar; }
    public void setLugar(String lugar) { this.lugar = lugar; }

    @Override
    public int compareTo(Evento o) {
        int cmp = this.fecha.compareTo(o.fecha);
        if (cmp != 0) return cmp;
        return this.nombre.compareToIgnoreCase(o.nombre);
    }

    @Override
    public String toString() {
        return nombre + " (" + fecha + ") - " + horas + " HL";
    }
}
