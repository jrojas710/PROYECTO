package com.ghl_unab.model;

import java.time.LocalDateTime;

public class Notificacion {
    private String mensaje;
    private LocalDateTime fecha;

    public Notificacion(String mensaje) {
        this.mensaje = mensaje;
        this.fecha = LocalDateTime.now();
    }

    public String getMensaje() { return mensaje; }
    public LocalDateTime getFecha() { return fecha; }

    @Override
    public String toString() {
        return "[" + fecha.toLocalDate() + "] " + mensaje;
    }
}
