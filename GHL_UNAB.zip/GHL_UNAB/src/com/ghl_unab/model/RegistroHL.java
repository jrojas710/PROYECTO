package com.ghl_unab.model;

import java.time.LocalDate;

public class RegistroHL {
    private int id;
    private int estudianteId;
    private int eventoId;
    private LocalDate fecha;
    private int horas;
    private String estado; // PENDIENTE, VALIDADA, RECHAZADA

    public RegistroHL(int id, int estudianteId, int eventoId, LocalDate fecha, int horas, String estado) {
        this.id = id;
        this.estudianteId = estudianteId;
        this.eventoId = eventoId;
        this.fecha = fecha;
        this.horas = horas;
        this.estado = estado;
    }

    public RegistroHL(int estudianteId, int eventoId, LocalDate fecha, int horas, String estado) {
        this(0, estudianteId, eventoId, fecha, horas, estado);
    }

    public int getId() { return id; }
    public void setId(int id) { this.id = id; }
    public int getEstudianteId() { return estudianteId; }
    public void setEstudianteId(int estudianteId) { this.estudianteId = estudianteId; }
    public int getEventoId() { return eventoId; }
    public void setEventoId(int eventoId) { this.eventoId = eventoId; }
    public LocalDate getFecha() { return fecha; }
    public void setFecha(LocalDate fecha) { this.fecha = fecha; }
    public int getHoras() { return horas; }
    public void setHoras(int horas) { this.horas = horas; }
    public String getEstado() { return estado; }
    public void setEstado(String estado) { this.estado = estado; }
}
