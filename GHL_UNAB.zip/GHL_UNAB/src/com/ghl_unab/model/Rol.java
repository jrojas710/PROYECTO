package com.ghl_unab.model;

public enum Rol {
    ESTUDIANTE,
    COORDINADOR,
    ADMIN
}
