package com.ghl_unab.model;

public class Usuario {

    private int id;
    private String nombre;
    private String correo;
    private String password;  // en BD se almacena el hash SHA-256
    private String programa;
    private String rol;       // ESTUDIANTE / ADMIN

    // Constructor usado al leer desde la BD (login)
    public Usuario(int id, String nombre, String correo, String password, String programa, String rol) {
        this.id = id;
        this.nombre = nombre;
        this.correo = correo;
        this.password = password;
        this.programa = programa;
        this.rol = rol;
    }

    // Constructor usado para registro (id = 0)
    public Usuario(String nombre, String correo, String password, String programa, String rol) {
        this(0, nombre, correo, password, programa, rol);
    }

    // ===== GETTERS =====
    public int getId() {
        return id;
    }

    public String getNombre() {
        return nombre;
    }

    public String getCorreo() {
        return correo;
    }

    public String getPassword() {
        return password;
    }

    public String getPrograma() {
        return programa;
    }

    public String getRol() {
        return rol;
    }

    // ===== SETTERS =====
    public void setId(int id) {
        this.id = id;
    }

    public void setNombre(String nombre) {
        this.nombre = nombre;
    }

    public void setCorreo(String correo) {
        this.correo = correo;
    }

    public void setPassword(String password) {
        this.password = password;
    }

    public void setPrograma(String programa) {
        this.programa = programa;
    }

    public void setRol(String rol) {
        this.rol = rol;
    }

    @Override
    public String toString() {
        return nombre + " (" + correo + ")";
    }
}
