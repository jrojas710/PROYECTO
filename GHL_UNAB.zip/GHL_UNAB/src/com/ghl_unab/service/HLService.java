package com.ghl_unab.service;

import com.ghl_unab.dao.EventoDAO;
import com.ghl_unab.dao.RegistroHLDAO;
import com.ghl_unab.model.Evento;
import com.ghl_unab.model.RegistroHL;

import java.sql.SQLException;
import java.time.LocalDate;
import java.time.Month;
import java.util.*;

public class HLService {

    private final EventoDAO eventoDAO;
    private final RegistroHLDAO registroDAO;

    // Estructuras de datos
    private final List<Evento> eventos = new ArrayList<>();
    private final Map<Integer, Evento> eventoPorId = new HashMap<>();
    private final TreeSet<Evento> eventosOrdenados = new TreeSet<>();
    private final PriorityQueue<Evento> proximosEventos = new PriorityQueue<>();

    public HLService(EventoDAO eventoDAO, RegistroHLDAO registroDAO) {
        this.eventoDAO = eventoDAO;
        this.registroDAO = registroDAO;

        // seed de eventos si la tabla está vacía
        try {
            this.eventoDAO.seed();
        } catch (SQLException e) {
            e.printStackTrace();
        }

        recargarEventos();
    }

    public RegistroHLDAO getRegistroDAO() {
        return registroDAO;
    }

    public EventoDAO getEventoDAO() {
        return eventoDAO;
    }

    // Recargar eventos desde BD a las estructuras
    public final void recargarEventos() {
        eventos.clear();
        eventoPorId.clear();
        eventosOrdenados.clear();
        proximosEventos.clear();

        try {
            List<Evento> lista = eventoDAO.findAll();
            for (Evento e : lista) {
                eventos.add(e);
                eventoPorId.put(e.getId(), e);
                eventosOrdenados.add(e);
                if (e.getFecha().isAfter(LocalDate.now().minusDays(1))) {
                    proximosEventos.add(e);
                }
            }
        } catch (SQLException e) {
            e.printStackTrace();
        }
    }

    public List<Evento> getEventos() {
        return Collections.unmodifiableList(eventos);
    }

    public Evento getEventoPorId(int id) {
        return eventoPorId.get(id);
    }

    public Evento getProximoEvento() {
        return proximosEventos.peek();
    }

    public Map<Month, Integer> calcularHorasPorMes(int estudianteId) {
        Map<Month, Integer> map = new EnumMap<>(Month.class);

        try {
            List<RegistroHL> registros = registroDAO.findByEstudiante(estudianteId);
            for (RegistroHL r : registros) {
                Month m = r.getFecha().getMonth();
                map.put(m, map.getOrDefault(m, 0) + r.getHoras());
            }
        } catch (SQLException e) {
        e.printStackTrace();
        }

        return map;
    }

    public List<Evento> recomendarEventos(int horasFaltantes) {
        List<Evento> lista = new ArrayList<>();

        for (Evento e : eventosOrdenados) {
            if (e.getFecha().isAfter(LocalDate.now()) && e.getHoras() >= 2) {
                lista.add(e);
            }
            if (lista.size() >= 5) break;
        }

        return lista;
    }

    public String calcularNivel(int estudianteId) {
        try {
            int horas = registroDAO.sumHorasValidadas(estudianteId);

            if (horas < 20) return "Principiante";
            if (horas < 50) return "Intermedio";
            if (horas < 80) return "Avanzado";
            return "Experto";

        } catch (Exception e) {
            return "Desconocido";
        }
    }
}
