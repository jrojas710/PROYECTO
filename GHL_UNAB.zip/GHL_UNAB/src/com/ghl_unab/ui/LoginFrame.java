package com.ghl_unab.ui;

import com.ghl_unab.dao.UsuarioDAO;
import com.ghl_unab.model.Usuario;
import com.ghl_unab.util.PasswordUtil;

import javax.swing.*;
import java.awt.*;
import java.sql.SQLException;

public class LoginFrame extends JFrame {

    private final UsuarioDAO usuarioDAO = new UsuarioDAO();

    private JTextField txtCorreo;
    private JPasswordField txtPassword;
    private JLabel lblMensaje;

    // PALETA VERDE
    private final Color verdeFondo = new Color(0x0F3D35);
    private final Color verdeCard  = new Color(0x145A4F);
    private final Color verdeClaro = new Color(0xE4F2EF);
    private final Color verdeBoton = new Color(0x1E7F6A);
    private final Color verdeHover = new Color(0x259F85);

    public LoginFrame() {
        initUI();
    }

    private void initUI() {
        setTitle("GHL-UNAB - Login");
        setSize(460, 360);
        setLocationRelativeTo(null);
        setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);

        setLayout(new GridBagLayout());
        getContentPane().setBackground(verdeFondo);

        JPanel card = new JPanel();
        card.setPreferredSize(new Dimension(360, 240));
        card.setBackground(verdeCard);
        card.setLayout(new GridBagLayout());
        card.setBorder(BorderFactory.createCompoundBorder(
                BorderFactory.createEmptyBorder(20, 20, 20, 20),
                BorderFactory.createMatteBorder(2, 2, 6, 6, new Color(0, 0, 0, 80))
        ));

        GridBagConstraints gbc = new GridBagConstraints();
        gbc.insets = new Insets(8, 8, 8, 8);
        gbc.fill = GridBagConstraints.HORIZONTAL;

        JLabel lbl1 = new JLabel("Correo UNAB:");
        lbl1.setForeground(verdeClaro);
        lbl1.setFont(new Font("Arial", Font.BOLD, 14));

        txtCorreo = new JTextField();
        estilizarCampo(txtCorreo);

        JLabel lbl2 = new JLabel("Contraseña:");
        lbl2.setForeground(verdeClaro);
        lbl2.setFont(new Font("Arial", Font.BOLD, 14));

        txtPassword = new JPasswordField();
        estilizarCampo(txtPassword);

        lblMensaje = new JLabel("", SwingConstants.CENTER);
        lblMensaje.setForeground(Color.RED);

        JButton btnRegistrar = boton("Registrarse");
        JButton btnLogin = boton("Ingresar");

        btnRegistrar.addActionListener(e -> new RegisterDialog(this, usuarioDAO).setVisible(true));
        btnLogin.addActionListener(e -> login());

        gbc.gridx = 0; gbc.gridy = 0; gbc.gridwidth = 2;
        card.add(lbl1, gbc);

        gbc.gridy = 1;
        card.add(txtCorreo, gbc);

        gbc.gridy = 2;
        card.add(lbl2, gbc);

        gbc.gridy = 3;
        card.add(txtPassword, gbc);

        gbc.gridy = 4;
        card.add(lblMensaje, gbc);

        gbc.gridwidth = 1;
        gbc.gridy = 5;
        gbc.gridx = 0;
        card.add(btnRegistrar, gbc);

        gbc.gridx = 1;
        card.add(btnLogin, gbc);

        add(card);
    }

    private void estilizarCampo(JComponent c) {
        c.setPreferredSize(new Dimension(200, 28));
        c.setBackground(verdeClaro);
        c.setBorder(BorderFactory.createEmptyBorder(5, 5, 5, 5));
    }

    private JButton boton(String texto) {
        JButton b = new JButton(texto);
        b.setBackground(verdeBoton);
        b.setForeground(Color.WHITE);
        b.setFocusPainted(false);
        b.setFont(new Font("Arial", Font.BOLD, 13));

        b.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseEntered(java.awt.event.MouseEvent e) { b.setBackground(verdeHover); }
            public void mouseExited(java.awt.event.MouseEvent e) { b.setBackground(verdeBoton); }
        });

        return b;
    }

    private void login() {
        try {
            String correo = txtCorreo.getText().trim();
            String pass = new String(txtPassword.getPassword()).trim();

            Usuario u = usuarioDAO.login(correo, pass);
            if (u == null) {
                lblMensaje.setText("Credenciales incorrectas");
                return;
            }

            dispose();
            new MainFrame(u).setVisible(true);

        } catch (SQLException ex) {
            ex.printStackTrace();
            JOptionPane.showMessageDialog(this, "Error en BD", "Error", JOptionPane.ERROR_MESSAGE);
        }
    }
}
