package com.ghl_unab.ui;

import com.ghl_unab.dao.EventoDAO;
import com.ghl_unab.dao.RegistroHLDAO;
import com.ghl_unab.model.Usuario;
import com.ghl_unab.service.HLService;
import com.ghl_unab.ui.panel.DashboardPanel;
import com.ghl_unab.ui.panel.EventosPanel;
import com.ghl_unab.ui.panel.HorasLibresPanel;
import com.ghl_unab.ui.panel.PerfilPanel;

import javax.swing.*;
import java.awt.*;
import java.awt.event.MouseAdapter;
import java.awt.event.MouseEvent;

public class MainFrame extends JFrame {

    private enum Section {
        DASHBOARD, HL, EVENTOS, PERFIL
    }

    private final Usuario usuario;
    private final HLService hlService;

    private final JPanel contentPanel = new JPanel(new BorderLayout());
    private JPanel sidebar;

    private Section activeSection = Section.DASHBOARD;

    private JButton btnDashboard;
    private JButton btnHL;
    private JButton btnEventos;
    private JButton btnPerfil;

    // Paleta de verdes
    private final Color VERDE_OSCURO = Color.decode("#0B3D2E");
    private final Color VERDE_MEDIO  = Color.decode("#145A40");
    private final Color VERDE_CLARO  = Color.decode("#1F7A53");
    private final Color VERDE_SUAVE  = Color.decode("#DFF5E3");

    public MainFrame(Usuario usuario) {
        this.usuario = usuario;
        this.hlService = new HLService(new EventoDAO(), new RegistroHLDAO());
        initUi();
    }

    private void initUi() {
        setTitle("GHL-UNAB – Panel Principal");
        setSize(1100, 680);
        setLocationRelativeTo(null);
        setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        setLayout(new BorderLayout());

        sidebar = buildSidebar();
        add(sidebar, BorderLayout.WEST);
        add(contentPanel, BorderLayout.CENTER);

        showDashboard();
    }

    private JPanel buildSidebar() {
        JPanel panel = new JPanel();
        panel.setPreferredSize(new Dimension(190, 0));
        panel.setLayout(new BoxLayout(panel, BoxLayout.Y_AXIS));
        panel.setBackground(VERDE_OSCURO);
        panel.setBorder(BorderFactory.createEmptyBorder(25, 10, 25, 10));

        JLabel title = new JLabel("GHL - UNAB");
        title.setAlignmentX(Component.CENTER_ALIGNMENT);
        title.setForeground(Color.WHITE);
        title.setFont(new Font("Arial", Font.BOLD, 18));

        panel.add(title);
        panel.add(Box.createVerticalStrut(30));

        btnDashboard = createSidebarButton("🏠  General", Section.DASHBOARD);
        btnHL        = createSidebarButton("⏱  Horas Libres", Section.HL);
        btnEventos   = createSidebarButton("📅  Eventos", Section.EVENTOS);
        btnPerfil    = createSidebarButton("👤  Perfil", Section.PERFIL);

        panel.add(btnDashboard);
        panel.add(Box.createVerticalStrut(12));
        panel.add(btnHL);
        panel.add(Box.createVerticalStrut(12));
        panel.add(btnEventos);
        panel.add(Box.createVerticalStrut(12));
        panel.add(btnPerfil);

        return panel;
    }

    private JButton createSidebarButton(String text, Section section) {
        JButton btn = new JButton(text);
        btn.setMaximumSize(new Dimension(170, 45));
        btn.setAlignmentX(Component.CENTER_ALIGNMENT);
        btn.setFocusPainted(false);
        btn.setBorder(BorderFactory.createEmptyBorder(8, 12, 8, 12));
        btn.setHorizontalAlignment(SwingConstants.LEFT);
        btn.setFont(new Font("Arial", Font.BOLD, 13));

        btn.addActionListener(e -> {
            switch (section) {
                case DASHBOARD -> showDashboard();
                case HL        -> showHL();
                case EVENTOS   -> showEventos();
                case PERFIL    -> showPerfil();
            }
        });

        // Hover
        btn.addMouseListener(new MouseAdapter() {
            @Override
            public void mouseEntered(MouseEvent e) {
                if (section != activeSection) {
                    btn.setBackground(VERDE_MEDIO);
                    btn.setForeground(Color.WHITE);
                }
            }

            @Override
            public void mouseExited(MouseEvent e) {
                refreshSidebarStyles();
            }
        });

        refreshSidebarStyles();
        return btn;
    }

    private void refreshSidebarStyles() {
        styleButton(btnDashboard, activeSection == Section.DASHBOARD);
        styleButton(btnHL,        activeSection == Section.HL);
        styleButton(btnEventos,   activeSection == Section.EVENTOS);
        styleButton(btnPerfil,    activeSection == Section.PERFIL);
    }

    private void styleButton(JButton btn, boolean active) {
        if (btn == null) return;

        if (active) {
            btn.setBackground(VERDE_CLARO);
            btn.setForeground(Color.WHITE);
            btn.setBorder(BorderFactory.createCompoundBorder(
                    BorderFactory.createLineBorder(Color.WHITE, 1),
                    BorderFactory.createEmptyBorder(8, 12, 8, 12)
            ));
        } else {
            btn.setBackground(new Color(0, 0, 0, 0)); // transparente sobre verde oscuro
            btn.setForeground(new Color(230, 230, 230));
            btn.setBorder(BorderFactory.createEmptyBorder(8, 12, 8, 12));
        }
    }

    private void setActiveSection(Section section) {
        this.activeSection = section;
        refreshSidebarStyles();
    }

    private void showDashboard() {
        contentPanel.removeAll();
        contentPanel.add(new DashboardPanel(usuario, hlService), BorderLayout.CENTER);
        setActiveSection(Section.DASHBOARD);
        contentPanel.revalidate();
        contentPanel.repaint();
    }

    private void showHL() {
        contentPanel.removeAll();
        contentPanel.add(new HorasLibresPanel(usuario, hlService), BorderLayout.CENTER);
        setActiveSection(Section.HL);
        contentPanel.revalidate();
        contentPanel.repaint();
    }

    private void showEventos() {
        contentPanel.removeAll();
        contentPanel.add(new EventosPanel(hlService), BorderLayout.CENTER);
        setActiveSection(Section.EVENTOS);
        contentPanel.revalidate();
        contentPanel.repaint();
    }

    private void showPerfil() {
        contentPanel.removeAll();
        contentPanel.add(new PerfilPanel(usuario, hlService), BorderLayout.CENTER);
        setActiveSection(Section.PERFIL);
        contentPanel.revalidate();
        contentPanel.repaint();
    }
}
