package com.ghl_unab.ui;

import com.ghl_unab.dao.UsuarioDAO;
import com.ghl_unab.model.Usuario;
import com.ghl_unab.util.PasswordUtil;

import javax.swing.*;
import java.awt.*;

public class RegisterDialog extends JDialog {

    private JTextField txtNombre, txtCorreo, txtPrograma;
    private JPasswordField txtPass1, txtPass2;

    private final Color verdeFondo = new Color(0x0F3D35);
    private final Color verdeCard  = new Color(0x145A4F);
    private final Color verdeClaro = new Color(0xE4F2EF);
    private final Color verdeBoton = new Color(0x1E7F6A);
    private final Color verdeHover = new Color(0x259F85);

    private final UsuarioDAO usuarioDAO;

    public RegisterDialog(Frame owner, UsuarioDAO usuarioDAO) {
        super(owner, "Registro de Usuario", true);
        this.usuarioDAO = usuarioDAO;

        initUI();
    }

    private void initUI() {
        setSize(460, 440);
        setLocationRelativeTo(null);
        setLayout(new GridBagLayout());
        getContentPane().setBackground(verdeFondo);

        JPanel card = new JPanel(new GridBagLayout());
        card.setPreferredSize(new Dimension(370, 340));
        card.setBackground(verdeCard);
        card.setBorder(BorderFactory.createCompoundBorder(
                BorderFactory.createEmptyBorder(20, 20, 20, 20),
                BorderFactory.createMatteBorder(2, 2, 6, 6, new Color(0, 0, 0, 80))
        ));

        GridBagConstraints gbc = new GridBagConstraints();
        gbc.insets = new Insets(8, 8, 8, 8);
        gbc.fill = GridBagConstraints.HORIZONTAL;

        txtNombre = new JTextField();
        txtCorreo = new JTextField();
        txtPrograma = new JTextField();
        txtPass1 = new JPasswordField();
        txtPass2 = new JPasswordField();

        estilizar(txtNombre);
        estilizar(txtCorreo);
        estilizar(txtPrograma);
        estilizar(txtPass1);
        estilizar(txtPass2);

        gbc.gridx = 0; gbc.gridy = 0;
        card.add(label("Nombre:"), gbc);
        gbc.gridy++;
        card.add(txtNombre, gbc);

        gbc.gridy++;
        card.add(label("Correo UNAB:"), gbc);
        gbc.gridy++;
        card.add(txtCorreo, gbc);

        gbc.gridy++;
        card.add(label("Programa:"), gbc);
        gbc.gridy++;
        card.add(txtPrograma, gbc);

        gbc.gridy++;
        card.add(label("Contraseña:"), gbc);
        gbc.gridy++;
        card.add(txtPass1, gbc);

        gbc.gridy++;
        card.add(label("Repite contraseña:"), gbc);
        gbc.gridy++;
        card.add(txtPass2, gbc);

        JButton btnRegistrar = boton("Crear Cuenta");
        gbc.gridy++;
        card.add(btnRegistrar, gbc);

        btnRegistrar.addActionListener(e -> registrar());

        add(card);
    }

    private JLabel label(String t) {
        JLabel l = new JLabel(t);
        l.setForeground(verdeClaro);
        l.setFont(new Font("Arial", Font.BOLD, 14));
        return l;
    }

    private void estilizar(JComponent c) {
        c.setBackground(verdeClaro);
        c.setBorder(BorderFactory.createEmptyBorder(5, 5, 5, 5));
    }

    private JButton boton(String text) {
        JButton b = new JButton(text);
        b.setBackground(verdeBoton);
        b.setForeground(Color.WHITE);
        b.setFont(new Font("Arial", Font.BOLD, 13));
        b.setFocusPainted(false);

        b.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseEntered(java.awt.event.MouseEvent evt) { b.setBackground(verdeHover); }
            public void mouseExited(java.awt.event.MouseEvent evt) { b.setBackground(verdeBoton); }
        });

        return b;
    }

    private void registrar() {
        try {
            String nom = txtNombre.getText().trim();
            String cor = txtCorreo.getText().trim();
            String pro = txtPrograma.getText().trim();
            String p1 = new String(txtPass1.getPassword());
            String p2 = new String(txtPass2.getPassword());

            if (!p1.equals(p2)) {
                JOptionPane.showMessageDialog(this, "Contraseñas no coinciden", "Error", JOptionPane.WARNING_MESSAGE);
                return;
            }

            String hash = PasswordUtil.hash(p1);

            Usuario u = new Usuario(nom, cor, hash, pro, "ESTUDIANTE");
            usuarioDAO.insertar(u);

            JOptionPane.showMessageDialog(this, "Registro exitoso");
            dispose();

        } catch (Exception ex) {
            ex.printStackTrace();
            JOptionPane.showMessageDialog(this, "Error registrando usuario", "Error", JOptionPane.ERROR_MESSAGE);
        }
    }
}
