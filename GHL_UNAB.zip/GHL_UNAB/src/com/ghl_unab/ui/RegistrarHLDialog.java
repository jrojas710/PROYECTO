package com.ghl_unab.ui;

import com.ghl_unab.model.Evento;
import com.ghl_unab.model.RegistroHL;
import com.ghl_unab.model.Usuario;
import com.ghl_unab.service.HLService;
import com.ghl_unab.ui.panel.HorasLibresPanel;

import javax.swing.*;
import java.awt.*;
import java.sql.SQLException;
import java.time.LocalDate;

public class RegistrarHLDialog extends JDialog {

    private final Usuario usuario;
    private final HLService hlService;
    private final HorasLibresPanel parentPanel;

    private final JComboBox<Evento> comboEventos;
    private final JTextField txtHoras;

    private final Color verdeOscuro = Color.decode("#0B3D2E");
    private final Color verdeClaro  = Color.decode("#1F7A53");
    private final Color verdeSuave  = Color.decode("#DFF5E3");

    public RegistrarHLDialog(Usuario usuario, HLService hlService, HorasLibresPanel parentPanel) {
        super((Frame) null, "Registrar Horas Libres", true);
        this.usuario = usuario;
        this.hlService = hlService;
        this.parentPanel = parentPanel;

        setSize(420, 260);
        setLocationRelativeTo(null);
        setLayout(new BorderLayout(10, 10));
        getContentPane().setBackground(verdeSuave);

        JPanel form = new JPanel(new GridLayout(0, 2, 8, 8));
        form.setBackground(verdeSuave);
        form.setBorder(BorderFactory.createEmptyBorder(10, 10, 10, 10));

        comboEventos = new JComboBox<>();
        for (Evento e : hlService.getEventos()) comboEventos.addItem(e);

        txtHoras = new JTextField();

        form.add(new JLabel("Evento:"));
        form.add(comboEventos);
        form.add(new JLabel("Horas obtenidas:"));
        form.add(txtHoras);

        add(form, BorderLayout.CENTER);

        JButton btnGuardar = new JButton("Guardar");
        JButton btnCancelar = new JButton("Cancelar");

        btnGuardar.setBackground(verdeClaro);
        btnGuardar.setForeground(Color.WHITE);

        btnCancelar.setBackground(Color.LIGHT_GRAY);

        btnGuardar.addActionListener(e -> guardar());
        btnCancelar.addActionListener(e -> dispose());

        JPanel bottom = new JPanel(new FlowLayout(FlowLayout.RIGHT));
        bottom.setBackground(verdeSuave);
        bottom.add(btnCancelar);
        bottom.add(btnGuardar);

        add(bottom, BorderLayout.SOUTH);
    }

    private void guardar() {
        try {
            if (comboEventos.getItemCount() == 0)
                throw new IllegalStateException("No hay eventos disponibles.");

            Evento evento = (Evento) comboEventos.getSelectedItem();
            if (evento == null)
                throw new IllegalStateException("Selecciona un evento.");

            int horas = Integer.parseInt(txtHoras.getText().trim());
            if (horas <= 0) throw new NumberFormatException();

            RegistroHL r = new RegistroHL(
                    usuario.getId(),
                    evento.getId(),
                    LocalDate.now(),
                    horas,
                    "VALIDADA"
            );

            hlService.getRegistroDAO().insertar(r);

            parentPanel.recargarTabla();

            JOptionPane.showMessageDialog(this,
                    "Horas registradas con éxito.",
                    "OK",
                    JOptionPane.INFORMATION_MESSAGE);

            dispose();

        } catch (NumberFormatException ex) {
            JOptionPane.showMessageDialog(this,
                    "Horas inválidas.",
                    "Error",
                    JOptionPane.WARNING_MESSAGE);
        } catch (IllegalStateException ex) {
            JOptionPane.showMessageDialog(this,
                    ex.getMessage(),
                    "Advertencia",
                    JOptionPane.WARNING_MESSAGE);
        } catch (SQLException ex) {
            ex.printStackTrace();
            JOptionPane.showMessageDialog(this,
                    "Error guardando HL.",
                    "Error",
                    JOptionPane.ERROR_MESSAGE);
        }
    }
}
