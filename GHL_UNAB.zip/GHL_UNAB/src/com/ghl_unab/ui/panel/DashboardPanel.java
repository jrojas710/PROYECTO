package com.ghl_unab.ui.panel;

import com.ghl_unab.model.Evento;
import com.ghl_unab.model.Usuario;
import com.ghl_unab.service.HLService;

import javax.swing.*;
import java.awt.*;
import java.time.Month;
import java.util.Map;

public class DashboardPanel extends JPanel {

    private final Color VERDE_OSCURO = Color.decode("#0B3D2E");
    private final Color VERDE_MEDIO  = Color.decode("#145A40");
    private final Color VERDE_CLARO  = Color.decode("#1F7A53");
    private final Color VERDE_SUAVE  = Color.decode("#DFF5E3");

    public DashboardPanel(Usuario usuario, HLService hlService) {

        setLayout(new BorderLayout(20, 20));
        setBorder(BorderFactory.createEmptyBorder(20, 20, 20, 20));
        setBackground(VERDE_SUAVE);

        // Datos
        int horasValidadas = 0;
        try {
            horasValidadas = hlService.getRegistroDAO().sumHorasValidadas(usuario.getId());
        } catch (Exception ignored) {}

        int meta = 100;
        int faltantes = Math.max(0, meta - horasValidadas);
        String nivel = hlService.calcularNivel(usuario.getId());
        Evento proximo = hlService.getProximoEvento();
        String proximoTxt = (proximo != null)
                ? proximo.getNombre() + " (" + proximo.getFecha() + ")"
                : "No hay próximos eventos";

        Map<Month, Integer> horasMes = hlService.calcularHorasPorMes(usuario.getId());

        // Título
        JLabel titulo = new JLabel("Resumen general de Horas Libres");
        titulo.setFont(new Font("Arial", Font.BOLD, 20));
        titulo.setForeground(VERDE_OSCURO);
        add(titulo, BorderLayout.NORTH);

        // Cards
        JPanel cards = new JPanel(new GridLayout(1, 4, 15, 15));
        cards.setOpaque(false);

        cards.add(buildCard("Horas acumuladas", horasValidadas + " HL"));
        cards.add(buildCard("Horas faltantes", faltantes + " HL"));
        cards.add(buildCard("Nivel", nivel));
        cards.add(buildCard("Próximo evento", proximoTxt));

        add(cards, BorderLayout.CENTER);

        // Panel inferior: gauge + gráfica
        JPanel bottom = new JPanel(new BorderLayout(20, 20));
        bottom.setOpaque(false);

        JPanel gaugeWrapper = new JPanel(new BorderLayout());
        gaugeWrapper.setOpaque(false);
        gaugeWrapper.add(new GaugePanel(horasValidadas, meta), BorderLayout.CENTER);

        JPanel gaugeCard = new JPanel(new BorderLayout());
        gaugeCard.setBackground(Color.WHITE);
        gaugeCard.setBorder(cardBorder());
        gaugeCard.add(gaugeWrapper, BorderLayout.CENTER);

        JPanel chartCard = new JPanel(new BorderLayout());
        chartCard.setBackground(Color.WHITE);
        chartCard.setBorder(cardBorder());
        chartCard.add(new JLabel("Horas por mes", SwingConstants.CENTER),
                BorderLayout.NORTH);
        chartCard.add(new HorasMesChartPanel(horasMes), BorderLayout.CENTER);

        bottom.add(gaugeCard, BorderLayout.WEST);
        bottom.add(chartCard, BorderLayout.CENTER);

        add(bottom, BorderLayout.SOUTH);
    }

    private JPanel buildCard(String title, String value) {
        JPanel p = new JPanel(new BorderLayout());
        p.setBackground(Color.WHITE);
        p.setBorder(cardBorder());

        JLabel lt = new JLabel(title);
        lt.setBorder(BorderFactory.createEmptyBorder(10, 12, 0, 12));
        lt.setFont(new Font("Arial", Font.BOLD, 14));
        lt.setForeground(VERDE_MEDIO);

        JLabel lv = new JLabel(value, SwingConstants.CENTER);
        lv.setFont(new Font("Arial", Font.BOLD, 24));
        lv.setForeground(VERDE_OSCURO);

        p.add(lt, BorderLayout.NORTH);
        p.add(lv, BorderLayout.CENTER);

        return p;
    }

    private javax.swing.border.Border cardBorder() {
        return BorderFactory.createCompoundBorder(
                BorderFactory.createMatteBorder(1, 1, 4, 1, new Color(0, 0, 0, 30)),
                BorderFactory.createEmptyBorder(8, 8, 12, 8)
        );
    }
}
