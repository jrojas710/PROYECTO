package com.ghl_unab.ui.panel;

import com.ghl_unab.model.Usuario;
import com.ghl_unab.service.HLService;

import javax.swing.*;
import java.awt.*;
import java.time.Month;
import java.util.Map;

public class EstadisticasPanel extends JPanel {

    public EstadisticasPanel(Usuario usuario, HLService service) {

        setLayout(new BorderLayout());
        setBorder(BorderFactory.createEmptyBorder(30, 30, 30, 30));

        Map<Month, Integer> horasMes = service.calcularHorasPorMes(usuario.getId());

        JPanel grid = new JPanel(new GridLayout(0, 2, 10, 10));

        for (Month m : Month.values()) {
            int horas = horasMes.getOrDefault(m, 0);
            JLabel label = new JLabel(m.toString() + ": " + horas + " HL");
            grid.add(label);
        }

        add(new JLabel("Horas por mes", SwingConstants.CENTER), BorderLayout.NORTH);
        add(grid, BorderLayout.CENTER);
    }
}
