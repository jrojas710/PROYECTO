package com.ghl_unab.ui.panel;

import com.ghl_unab.ui.WrapLayout;
import com.ghl_unab.model.Evento;
import com.ghl_unab.service.HLService;

import javax.swing.*;
import java.awt.*;
import java.util.List;
import java.util.stream.Collectors;

public class EventosPanel extends JPanel {

    private final HLService hlService;

    private final JTextField txtBuscar;
    private final JComboBox<String> cbTipo;

    private List<Evento> eventosActuales;

    private final Color verdeOscuro = Color.decode("#0B3D2E");
    private final Color verdeMedio  = Color.decode("#145A40");
    private final Color verdeClaro  = Color.decode("#1F7A53");
    private final Color verdeSuave  = Color.decode("#DFF5E3");

    public EventosPanel(HLService hlService) {
        this.hlService = hlService;

        setLayout(new BorderLayout(15, 15));
        setBorder(BorderFactory.createEmptyBorder(20, 20, 20, 20));
        setBackground(verdeSuave);

        // FILTROS
        txtBuscar = new JTextField(15);
        cbTipo = new JComboBox<>(new String[]{
                "Todos", "CULTURAL", "ACADEMICO", "DEPORTIVO", "ARTISTICO", "OTROS"
        });

        JButton btnFiltrar = new JButton("Filtrar");
        JButton btnLimpiar = new JButton("Limpiar");

        btnFiltrar.addActionListener(e -> aplicarFiltro());
        btnLimpiar.addActionListener(e -> {
            txtBuscar.setText("");
            cbTipo.setSelectedIndex(0);
            cargarEventos(hlService.getEventos());
        });

        JPanel filtros = new JPanel(new FlowLayout(FlowLayout.LEFT));
        filtros.setBackground(verdeSuave);
        filtros.add(new JLabel("Buscar:"));
        filtros.add(txtBuscar);
        filtros.add(new JLabel("Tipo:"));
        filtros.add(cbTipo);
        filtros.add(btnFiltrar);
        filtros.add(btnLimpiar);

        add(filtros, BorderLayout.NORTH);

        // CONTENEDOR DE TARJETAS
        JPanel cards = new JPanel();
        cards.setLayout(new WrapLayout(FlowLayout.LEFT, 20, 20)); // permite filas fluidas
        cards.setBackground(verdeSuave);

        JScrollPane scroll = new JScrollPane(cards);
        scroll.setBorder(null);
        scroll.getViewport().setBackground(verdeSuave);
        add(scroll, BorderLayout.CENTER);

        // CARGA INICIAL
        this.eventosActuales = hlService.getEventos();
        mostrarTarjetas(cards, eventosActuales);
    }

    private void mostrarTarjetas(JPanel cards, List<Evento> lista) {
        cards.removeAll();

        for (Evento e : lista) {
            JPanel card = new JPanel();
            card.setPreferredSize(new Dimension(260, 180));
            card.setLayout(new BorderLayout());
            card.setBackground(Color.WHITE);
            card.setBorder(BorderFactory.createCompoundBorder(
                    BorderFactory.createLineBorder(verdeClaro, 2),
                    BorderFactory.createEmptyBorder(12, 12, 12, 12)
            ));

            JLabel nombre = new JLabel(e.getNombre());
            nombre.setFont(new Font("Arial", Font.BOLD, 16));
            nombre.setForeground(verdeOscuro);

            JTextArea desc = new JTextArea(
                    "Fecha: " + e.getFecha() +
                    "\nTipo: " + e.getTipo() +
                    "\nHL: " + e.getHoras() +
                    "\nLugar: " + e.getLugar()
            );
            desc.setEditable(false);
            desc.setBackground(Color.WHITE);
            desc.setFont(new Font("Arial", Font.PLAIN, 12));

            card.add(nombre, BorderLayout.NORTH);
            card.add(desc, BorderLayout.CENTER);

            cards.add(card);
        }

        cards.revalidate();
        cards.repaint();
    }

    private void cargarEventos(List<Evento> lista) {
        this.eventosActuales = lista;
        aplicarFiltro();
    }

    private void aplicarFiltro() {
        String texto = txtBuscar.getText().trim().toLowerCase();
        String tipo = (String) cbTipo.getSelectedItem();

        List<Evento> filtrados = eventosActuales.stream()
                .filter(e ->
                        (texto.isEmpty()
                                || e.getNombre().toLowerCase().contains(texto)
                                || e.getLugar().toLowerCase().contains(texto))
                                && ("Todos".equalsIgnoreCase(tipo)
                                || e.getTipo().equalsIgnoreCase(tipo))
                )
                .collect(Collectors.toList());

        JPanel cont = (JPanel) ((JViewport)
                ((JScrollPane) getComponent(1)).getViewport()
        ).getView();

        mostrarTarjetas(cont, filtrados);
    }
}
