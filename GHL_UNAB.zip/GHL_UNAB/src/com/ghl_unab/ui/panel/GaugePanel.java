package com.ghl_unab.ui.panel;

import javax.swing.*;
import java.awt.*;

public class GaugePanel extends JPanel {

    private final int meta;
    private final int valor;
    private final Color VERDE_CLARO = Color.decode("#1F7A53");
    private final Color VERDE_OSCURO = Color.decode("#0B3D2E");

    public GaugePanel(int valor, int meta) {
        this.valor = Math.max(0, valor);
        this.meta = Math.max(1, meta);
        setOpaque(false);
        setPreferredSize(new Dimension(220, 220));
    }

    @Override
    protected void paintComponent(Graphics g) {
        super.paintComponent(g);
        Graphics2D g2 = (Graphics2D) g.create();
        g2.setRenderingHint(RenderingHints.KEY_ANTIALIASING,
                RenderingHints.VALUE_ANTIALIAS_ON);

        int size = Math.min(getWidth(), getHeight()) - 20;
        int x = (getWidth() - size) / 2;
        int y = (getHeight() - size) / 2;

        // Fondo
        g2.setColor(new Color(230, 230, 230));
        g2.setStroke(new BasicStroke(18));
        g2.drawArc(x, y, size, size, 135, 270);

        // Progreso
        float percent = Math.min(1f, valor / (float) meta);
        int angle = Math.round(270 * percent);

        g2.setColor(VERDE_CLARO);
        g2.drawArc(x, y, size, size, 135, angle);

        // Texto
        String centerText = valor + " / " + meta + " HL";
        String label = "Progreso total";

        g2.setFont(new Font("Arial", Font.BOLD, 18));
        FontMetrics fm = g2.getFontMetrics();
        int tx = (getWidth() - fm.stringWidth(centerText)) / 2;
        int ty = getHeight() / 2;
        g2.setColor(VERDE_OSCURO);
        g2.drawString(centerText, tx, ty);

        g2.setFont(new Font("Arial", Font.PLAIN, 13));
        fm = g2.getFontMetrics();
        int tx2 = (getWidth() - fm.stringWidth(label)) / 2;
        g2.drawString(label, tx2, ty + 20);

        g2.dispose();
    }
}
