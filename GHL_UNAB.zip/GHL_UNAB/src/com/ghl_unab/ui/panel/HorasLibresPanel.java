package com.ghl_unab.ui.panel;

import com.ghl_unab.model.Evento;
import com.ghl_unab.model.RegistroHL;
import com.ghl_unab.model.Usuario;
import com.ghl_unab.service.HLService;
import com.ghl_unab.ui.RegistrarHLDialog;
import com.ghl_unab.util.CSVExporter;

import javax.swing.*;
import javax.swing.table.DefaultTableModel;
import java.awt.*;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;

public class HorasLibresPanel extends JPanel {

    private final Usuario usuario;
    private final HLService hlService;

    private final DefaultTableModel modelo;
    private final JTable tabla;

    private final JTextField txtBuscar;

    private List<RegistroHL> registrosActuales = new ArrayList<>();

    public HorasLibresPanel(Usuario usuario, HLService hlService) {
        this.usuario = usuario;
        this.hlService = hlService;

        setLayout(new BorderLayout());
        setBorder(BorderFactory.createEmptyBorder(20, 20, 20, 20));

        // ============= BOTONES SUPERIORES =============
        JButton btnRegistrar = new JButton("Registrar nueva HL");
        btnRegistrar.addActionListener(e ->
                new RegistrarHLDialog(usuario, hlService, this).setVisible(true)
        );

        JButton btnExportar = new JButton("Exportar CSV");
        btnExportar.addActionListener(e -> exportarCSV());

        JButton btnEditar = new JButton("Editar selección");
        btnEditar.addActionListener(e -> editarSeleccion());

        JButton btnEliminar = new JButton("Eliminar selección");
        btnEliminar.addActionListener(e -> eliminarSeleccion());

        txtBuscar = new JTextField(15);
        JButton btnBuscar = new JButton("Buscar");
        btnBuscar.addActionListener(e -> filtrar());

        JButton btnLimpiar = new JButton("Limpiar filtro");
        btnLimpiar.addActionListener(e -> {
            txtBuscar.setText("");
            recargarTabla();
        });

        JPanel top = new JPanel(new FlowLayout(FlowLayout.LEFT));
        top.add(btnRegistrar);
        top.add(btnExportar);
        top.add(btnEditar);
        top.add(btnEliminar);
        top.add(new JLabel("Buscar:"));
        top.add(txtBuscar);
        top.add(btnBuscar);
        top.add(btnLimpiar);

        add(top, BorderLayout.NORTH);

        // ============= TABLA =============
        String[] columnas = {"Fecha", "Evento", "Horas", "Estado"};
        modelo = new DefaultTableModel(columnas, 0) {
            @Override
            public boolean isCellEditable(int row, int col) {
                return false; // Tabla solo lectura
            }
        };

        tabla = new JTable(modelo);
        tabla.setRowHeight(26);

        add(new JScrollPane(tabla), BorderLayout.CENTER);

        // ============= CARGA INICIAL =============
        recargarTabla();
    }

    // =====================================================
    // Recargar datos desde BD
    // =====================================================
    public void recargarTabla() {
        modelo.setRowCount(0);
        registrosActuales.clear();

        try {
            registrosActuales =
                    hlService.getRegistroDAO().findByEstudiante(usuario.getId());

            for (RegistroHL r : registrosActuales) {
                Evento evento = hlService.getEventoPorId(r.getEventoId());
                String nombreEvento = (evento != null) ? evento.getNombre() : "Evento no encontrado";

                Object[] fila = {
                        r.getFecha().toString(),
                        nombreEvento,
                        r.getHoras(),
                        r.getEstado()
                };

                modelo.addRow(fila);
            }

        } catch (SQLException ex) {
            ex.printStackTrace();
            JOptionPane.showMessageDialog(this,
                    "Error cargando HL de la base de datos.",
                    "Error",
                    JOptionPane.ERROR_MESSAGE);
        }
    }

    // =====================================================
    // Exportar CSV
    // =====================================================
    private void exportarCSV() {
        try {
            var registros = hlService.getRegistroDAO().findByEstudiante(usuario.getId());
            CSVExporter.exportarRegistros(registros);
        } catch (Exception ex) {
            JOptionPane.showMessageDialog(this,
                    "No fue posible exportar el archivo.",
                    "Error",
                    JOptionPane.ERROR_MESSAGE);
        }
    }

    // =====================================================
    // Editar selección
    // =====================================================
    private void editarSeleccion() {
        int row = tabla.getSelectedRow();
        if (row == -1) {
            JOptionPane.showMessageDialog(this,
                    "Selecciona una fila para editar.",
                    "Aviso",
                    JOptionPane.WARNING_MESSAGE);
            return;
        }

        RegistroHL r = registrosActuales.get(row);

        JTextField txtHoras = new JTextField(String.valueOf(r.getHoras()));
        String[] estados = {"PENDIENTE", "VALIDADA", "RECHAZADA"};
        JComboBox<String> cbEstado = new JComboBox<>(estados);
        cbEstado.setSelectedItem(r.getEstado());

        JPanel panel = new JPanel(new GridLayout(0, 2, 5, 5));
        panel.add(new JLabel("Horas:"));
        panel.add(txtHoras);
        panel.add(new JLabel("Estado:"));
        panel.add(cbEstado);

        int res = JOptionPane.showConfirmDialog(this, panel,
                "Editar registro HL", JOptionPane.OK_CANCEL_OPTION);

        if (res != JOptionPane.OK_OPTION) return;

        try {
            int nuevasHoras = Integer.parseInt(txtHoras.getText().trim());
            if (nuevasHoras <= 0) throw new NumberFormatException();

            String nuevoEstado = (String) cbEstado.getSelectedItem();

            hlService.getRegistroDAO()
                    .actualizarHorasYEstado(r.getId(), nuevasHoras, nuevoEstado);

            recargarTabla();

        } catch (NumberFormatException ex) {
            JOptionPane.showMessageDialog(this,
                    "Ingresa un número válido de horas.",
                    "Datos inválidos",
                    JOptionPane.WARNING_MESSAGE);
        } catch (SQLException ex) {
            JOptionPane.showMessageDialog(this,
                    "Error actualizando el registro.",
                    "Error",
                    JOptionPane.ERROR_MESSAGE);
        }
    }

    // =====================================================
    // Eliminar selección
    // =====================================================
    private void eliminarSeleccion() {
        int row = tabla.getSelectedRow();
        if (row == -1) {
            JOptionPane.showMessageDialog(this,
                    "Selecciona una fila para eliminar.",
                    "Aviso",
                    JOptionPane.WARNING_MESSAGE);
            return;
        }

        RegistroHL r = registrosActuales.get(row);

        int conf = JOptionPane.showConfirmDialog(this,
                "¿Seguro que deseas eliminar este registro de HL?",
                "Confirmar eliminación",
                JOptionPane.YES_NO_OPTION);

        if (conf != JOptionPane.YES_OPTION) return;

        try {
            hlService.getRegistroDAO().eliminar(r.getId());
            recargarTabla();
        } catch (SQLException ex) {
            JOptionPane.showMessageDialog(this,
                    "Error eliminando el registro.",
                    "Error",
                    JOptionPane.ERROR_MESSAGE);
        }
    }

    // =====================================================
    // Filtro de búsqueda
    // =====================================================
    private void filtrar() {
        String texto = txtBuscar.getText().trim().toLowerCase();

        if (texto.isEmpty()) {
            recargarTabla();
            return;
        }

        modelo.setRowCount(0);

        for (RegistroHL r : registrosActuales) {
            Evento e = hlService.getEventoPorId(r.getEventoId());
            String nombreEvento = (e != null) ? e.getNombre().toLowerCase() : "";
            String estado = r.getEstado().toLowerCase();

            boolean coincide = nombreEvento.contains(texto) || estado.contains(texto);

            if (coincide) {
                Object[] fila = {
                        r.getFecha().toString(),
                        (e != null) ? e.getNombre() : "Evento no encontrado",
                        r.getHoras(),
                        r.getEstado()
                };
                modelo.addRow(fila);
            }
        }
    }
}
