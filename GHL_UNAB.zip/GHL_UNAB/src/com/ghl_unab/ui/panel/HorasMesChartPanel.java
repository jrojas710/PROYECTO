package com.ghl_unab.ui.panel;

import javax.swing.*;
import java.awt.*;
import java.time.Month;
import java.util.Map;

public class HorasMesChartPanel extends JPanel {

    private final Map<Month, Integer> horasMes;
    private final Color VERDE_CLARO = Color.decode("#1F7A53");
    private final Color VERDE_OSCURO = Color.decode("#0B3D2E");

    public HorasMesChartPanel(Map<Month, Integer> horasMes) {
        this.horasMes = horasMes;
        setPreferredSize(new Dimension(450, 230));
        setBackground(Color.WHITE);
        setBorder(BorderFactory.createEmptyBorder(20, 30, 35, 25));
    }

    @Override
    protected void paintComponent(Graphics g) {
        super.paintComponent(g);
        if (horasMes == null) return;

        Graphics2D g2 = (Graphics2D) g.create();
        g2.setRenderingHint(RenderingHints.KEY_ANTIALIASING,
                RenderingHints.VALUE_ANTIALIAS_ON);

        int width = getWidth();
        int height = getHeight();

        int max = 0;
        for (Month m : Month.values()) {
            max = Math.max(max, horasMes.getOrDefault(m, 0));
        }
        if (max == 0) max = 1;

        int leftPad = 35;
        int bottomPad = 25;
        int usableHeight = height - bottomPad - 10;
        int usableWidth = width - leftPad - 10;

        int barWidth = usableWidth / 12 - 4;

        // Ejes
        g2.setColor(new Color(200, 200, 200));
        g2.drawLine(leftPad, 10, leftPad, height - bottomPad);
        g2.drawLine(leftPad, height - bottomPad, width - 5, height - bottomPad);

        // Barras
        int i = 0;
        for (Month m : Month.values()) {
            int valor = horasMes.getOrDefault(m, 0);
            int barHeight = (int) (valor / (float) max * (usableHeight - 15));

            int x = leftPad + 5 + i * (barWidth + 4);
            int y = height - bottomPad - barHeight;

            g2.setColor(VERDE_CLARO);
            g2.fillRoundRect(x, y, barWidth, barHeight, 6, 6);

            g2.setColor(VERDE_OSCURO);
            String label = m.toString().substring(0, 3);
            int tx = x + (barWidth - g2.getFontMetrics().stringWidth(label)) / 2;
            g2.drawString(label, tx, height - 8);

            i++;
        }

        g2.dispose();
    }
}
