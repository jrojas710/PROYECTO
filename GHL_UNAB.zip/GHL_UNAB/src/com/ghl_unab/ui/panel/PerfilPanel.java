package com.ghl_unab.ui.panel;

import com.ghl_unab.model.Usuario;
import com.ghl_unab.service.HLService;

import javax.swing.*;
import java.awt.*;

public class PerfilPanel extends JPanel {

    private final Usuario usuario;
    private final HLService hlService;

    // PALETA VERDE
    private final Color verdeFondo = new Color(0x0F3D35);
    private final Color verdeCard = new Color(0x145A4F);
    private final Color verdeTexto = new Color(0xE4F2EF);

    public PerfilPanel(Usuario usuario, HLService hlService) {
        this.usuario = usuario;
        this.hlService = hlService;

        initUI();
    }

    private void initUI() {
        setLayout(new BorderLayout());
        setBackground(verdeFondo);  

        JPanel card = new JPanel();
        card.setLayout(new GridLayout(4, 1, 20, 20));
        card.setBorder(BorderFactory.createEmptyBorder(40, 40, 40, 40));
        card.setBackground(verdeCard);

        // SOMBRA
        card.setBorder(BorderFactory.createCompoundBorder(
                BorderFactory.createEmptyBorder(20, 20, 20, 20),
                BorderFactory.createMatteBorder(2, 2, 6, 6, new Color(0, 0, 0, 60))
        ));

        // ADD DATA
        card.add(row("Nombre", usuario.getNombre()));
        card.add(row("Correo", usuario.getCorreo()));
        card.add(row("Programa", usuario.getPrograma()));
        
        // Rol es un String, no se usa .name()
        card.add(row("Rol", usuario.getRol()));

        add(card, BorderLayout.CENTER);
    }

    private JPanel row(String label, String value) {
        JPanel p = new JPanel(new GridLayout(1, 2));
        p.setOpaque(false);

        JLabel l1 = new JLabel(label + ":");
        l1.setForeground(verdeTexto);
        l1.setFont(new Font("Arial", Font.BOLD, 16));

        JLabel l2 = new JLabel(value);
        l2.setForeground(verdeTexto);
        l2.setFont(new Font("Arial", Font.PLAIN, 16));

        p.add(l1);
        p.add(l2);

        return p;
    }
}
