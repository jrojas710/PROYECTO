package com.ghl_unab.ui.panel;

import com.ghl_unab.model.Evento;
import com.ghl_unab.model.Usuario;
import com.ghl_unab.service.HLService;

import javax.swing.*;
import java.awt.*;
import java.util.List;

public class RecomendacionesPanel extends JPanel {

    public RecomendacionesPanel(Usuario usuario, HLService service) {

        setLayout(new BorderLayout(20, 20));
        setBorder(BorderFactory.createEmptyBorder(20, 20, 20, 20));

        int horasAcumuladas = 0;
        try {
            horasAcumuladas = service.getRegistroDAO()
                    .sumHorasValidadas(usuario.getId());
        } catch (Exception ignored) {}

        int horasParaGrado = 100;

        int faltantes = horasParaGrado - horasAcumuladas;

        List<Evento> lista = service.recomendarEventos(faltantes);

        JPanel panel = new JPanel(new GridLayout(0, 1, 10, 10));

        for (Evento e : lista) {
            panel.add(new JLabel(
                    e.getNombre() + " – " + e.getHoras() + " HL – " + e.getFecha()
            ));
        }

        add(new JLabel("Recomendaciones de eventos", SwingConstants.CENTER),
            BorderLayout.NORTH);
        add(panel, BorderLayout.CENTER);
    }
}
