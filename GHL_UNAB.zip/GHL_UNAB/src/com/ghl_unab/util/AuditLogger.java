package com.ghl_unab.util;

import java.io.FileWriter;
import java.io.IOException;
import java.io.PrintWriter;
import java.time.LocalDateTime;

public class AuditLogger {

    private static final String FILE = "auditoria.log";

    public static void log(String usuarioCorreo, String accion, String detalle) {
        try (PrintWriter out = new PrintWriter(new FileWriter(FILE, true))) {
            out.printf("%s | %s | %s | %s%n",
                    LocalDateTime.now(),
                    usuarioCorreo,
                    accion,
                    detalle);
        } catch (IOException e) {
            e.printStackTrace();
        }
    }

    // Versión alternativa más simple
    public static void log(String mensaje) {
        try (PrintWriter out = new PrintWriter(new FileWriter(FILE, true))) {
            out.printf("%s | %s%n",
                    LocalDateTime.now(),
                    mensaje);
        } catch (IOException e) {
            e.printStackTrace();
        }
    }
}
