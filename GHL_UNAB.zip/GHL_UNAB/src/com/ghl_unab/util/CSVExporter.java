package com.ghl_unab.util;

import com.ghl_unab.model.RegistroHL;

import javax.swing.*;
import java.io.FileWriter;
import java.io.IOException;
import java.util.List;

public class CSVExporter {

    public static void exportarRegistros(List<RegistroHL> registros) {
        JFileChooser chooser = new JFileChooser();
        chooser.setDialogTitle("Guardar archivo CSV");

        int result = chooser.showSaveDialog(null);
        if (result != JFileChooser.APPROVE_OPTION) return;

        String path = chooser.getSelectedFile().getAbsolutePath();

        if (!path.endsWith(".csv")) {
            path += ".csv";
        }

        try (FileWriter writer = new FileWriter(path)) {
            writer.write("Fecha,EventoID,Horas,Estado\n");

            for (RegistroHL r : registros) {
                writer.write(
                        r.getFecha() + "," +
                        r.getEventoId() + "," +
                        r.getHoras() + "," +
                        r.getEstado() + "\n"
                );
            }

            JOptionPane.showMessageDialog(null,
                    "Archivo exportado correctamente:\n" + path,
                    "Exportación exitosa",
                    JOptionPane.INFORMATION_MESSAGE);

        } catch (IOException ex) {
            JOptionPane.showMessageDialog(null,
                    "No se pudo crear el archivo.",
                    "Error",
                    JOptionPane.ERROR_MESSAGE);
        }
    }
}
