package com.ghl_unab.util;

import javax.swing.*;

public class Notifier {

    public static void info(String msg) {
        JOptionPane.showMessageDialog(null, msg,
                "Información", JOptionPane.INFORMATION_MESSAGE);
    }

    public static void warn(String msg) {
        JOptionPane.showMessageDialog(null, msg,
                "Advertencia", JOptionPane.WARNING_MESSAGE);
    }

    public static void error(String msg) {
        JOptionPane.showMessageDialog(null, msg,
                "Error", JOptionPane.ERROR_MESSAGE);
    }
}
